Dans cet exercice, j'ai tenté de mettre en pratique mes nouvelles connaissances... 

I.Front :

-Sass = compilation + partiels (_reset & _font)

-MediaQueries = le resultat doit se rapprocher du visuel pdf fourni + s'adapter au ieux à tous les écrans


II.Programmation mode débutant : 

-JS = manipuler les objets + les classes + le DOM


----------------------------------------------------------------------

Ainsi vous verrez que les styles color & italic sont appliqués avec JS.
Mais aussi que les dialogues des Pokemons sont insérés dans le HTML via JS.


----------------------------------------------------------------------

La prochaine étape : rendre le pokemonGenerator interactif avec le user. 
Via un formulaire, il entrera sa catégorie (PokemonTerre ou PokemonMarin) puis ses attributs = 
son nom, son poids, sa taille, nbPatte, cardiaque/tv 
OU 
son nom, son poids, son nbNageoire

A voir si on change les attributs pour rendre l'interaction + marrante

----------------------------------------------------------------------
